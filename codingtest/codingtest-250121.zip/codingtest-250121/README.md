erc-20 A토큰 1개당 0.001eth에 판매하되 그 가격은 판매 시작 이후부터 2일동안만 유지됩니다. (decimal은 0으로)

2일 이후부터는 개당 0.005eth에 판매할 예정입니다.

해당 컨트랙트를 구현하고 컴파일하고 배포하고 verify하는 과정을 모두 hardhat에서 진행하세요.

추가로 아래의 일을 수행하기 위해서 terminal에 작성되어야 하는 명령어를 별도의 txt 파일로 만들어서 제출해주세요.

1) hardhat 프로젝트 시작 
2) contract 컴파일
3) contract local testnet에 배포
4) contract sepolia testnet에 배포
5) sepolia에 배포된 contract verify 

제출은 zip 파일로 해주시면 됩니다.

---

npm i --save -dev hardhat
npx hardhat
npm i @openzeppelin/contracts
npm i dotenv

npx hardhat node
npx hardhat ignition deploy ./ignition/modules/deploy.js --network localhost
npx hardhat ignition deploy ./ignition/modules/deploy.js --network sepolia --deployment-id ERC20A
npx hardhat verify --network sepolia 0x8CA51B39F85Eb511aCFC3d2509e8dBf8Bd75D6C0
