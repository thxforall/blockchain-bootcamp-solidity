// This setup uses Hardhat Ignition to manage smart contract deployments.
// Learn more about it at https://hardhat.org/ignition

const { buildModule } = require('@nomicfoundation/hardhat-ignition/modules');

module.exports = buildModule('ERC20A', (m) => {
  const erc20a = m.contract('ERC20A');

  return { erc20a };
});
